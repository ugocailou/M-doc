import express from "express";
import fs from "fs";
import path from "path";
import { fileURLToPath } from "url";

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const app = express();
const PORT = process.env.PORT || 3000;

// Render fournit un disque persistant monté sur /data — sinon on utilise /tmp
const DATA_DIR = process.env.DATA_DIR || "/data";
const DB_FILE = path.join(DATA_DIR, "dossiers.json");

// S'assurer que le dossier de données existe
try { fs.mkdirSync(DATA_DIR, { recursive: true }); } catch {}

// Données en mémoire + fichier JSON (persistant sur Render avec un disque)
function readAll() {
  try {
    const raw = fs.readFileSync(DB_FILE, "utf8");
    const parsed = JSON.parse(raw);
    return Array.isArray(parsed) ? parsed : [];
  } catch {
    return [];
  }
}
function writeAll(list) {
  fs.writeFileSync(DB_FILE, JSON.stringify(list, null, 2), "utf8");
}

function clean(v, max = 4000) {
  if (typeof v !== "string") return "";
  return v.trim().slice(0, max);
}

app.use(express.json({ limit: "1mb" }));
app.use(express.static(path.join(__dirname, "public")));

// ---------- API ----------

// GET /api/records — liste tous les dossiers
app.get("/api/records", (req, res) => {
  try {
    res.json({ ok: true, records: readAll() });
  } catch (e) {
    res.status(500).json({ ok: false, error: e.message });
  }
});

// POST /api/records — ajouter un dossier
app.post("/api/records", (req, res) => {
  try {
    const p = req.body || {};
    const name = clean(p.name, 120);
    if (!name) return res.status(400).json({ ok: false, error: "Nom obligatoire." });

    const record = {
      id: clean(p.id, 40) || "D-" + Date.now().toString(36).toUpperCase(),
      ref: clean(p.ref, 60) || "REF/MED/" + new Date().getFullYear() + "-LIBRE",
      name,
      date: clean(p.date, 60) || new Date().toLocaleDateString("fr-FR"),
      unit: clean(p.unit, 120) || "Admission",
      status: ["traite", "encours", "deces"].includes(p.status) ? p.status : "encours",
      category: clean(p.category, 60) || "Général",
      tags: Array.isArray(p.tags) ? p.tags.slice(0, 8).map(t => clean(String(t), 40)).filter(Boolean) : [],
      summary: clean(p.summary, 600),
      body: clean(p.body, 8000),
      createdAt: new Date().toISOString(),
    };

    const list = readAll();
    list.push(record);
    writeAll(list);
    res.status(201).json({ ok: true, record });
  } catch (e) {
    res.status(500).json({ ok: false, error: e.message });
  }
});

// DELETE /api/records?id=XXX — supprimer un dossier
app.delete("/api/records", (req, res) => {
  try {
    const { id } = req.query;
    if (!id) return res.status(400).json({ ok: false, error: "id manquant." });
    const list = readAll();
    const next = list.filter(r => r.id !== id);
    writeAll(next);
    res.json({ ok: true, removed: list.length - next.length });
  } catch (e) {
    res.status(500).json({ ok: false, error: e.message });
  }
});

// POST /api/seed — pré-charger les dossiers existants (si vide)
app.post("/api/seed", (req, res) => {
  try {
    const existing = readAll();
    if (existing.length > 0) {
      return res.json({ ok: true, seeded: false, message: "Registre déjà rempli.", count: existing.length });
    }
    const SEED = [
      {id:"001",ref:"REF/MED/2026-0512-Z",name:"Zerath Cobalt",date:"12 / 05 / 2026",unit:"Admission · Soins intensifs",status:"traite",category:"Soins intensifs",tags:["Brûlure","Chirurgie oculaire","Antécédent DPPA"],summary:"Brûlure au flanc droit et retrait d'un œil nécrosé. Implant orbitaire provisoire posé.",body:"ANTÉCÉDENTS\n— Soins préalables DPPA. Brûlure flanc droit.\n\nINTERVENTIONS\n— Retrait œil nécrosé orbite droite.\n— Implant orbitaire provisoire posé.\n\nTRAITEMENT\n— Antalgiques, Antibiotiques, Protection œil sain."},
      {id:"002",ref:"REF/MED/2026-0512-F",name:"Diane Flori",date:"12 / 05 / 2026 → 13 / 05 / 2026",unit:"Admission · Urgences chirurgicales",status:"traite",category:"Neurochirurgie",tags:["Polytraumatisée","Brûlure","Éclats de grenade","Neurochirurgie"],summary:"Polytraumatisme par explosion. Neurochirurgie crânienne, drainage thoracique, fêlure pelvienne. Réveil confirmé.",body:"⚠ ERREUR MÉDICALE — Perfusion AB+ sur groupe O+ (Dr. Katchum). Insuffisance rénale aiguë corrigée.\n\nMEMBRES SUP — Éclats extraits, tulle gras.\nMEMBRE INF — Brûlures, tulle gras.\nNEUROCHIRURGIE — Plaque métallique, agrafes scalp.\nTHORAX — Débris retirés, valve drainage 2e espace intercostal.\nBASSIN — Fêlure, antalgie, fauteuil roulant.\nTRAITEMENT — Mannitol, Antibiotiques, Morphine, Kétamine.\n✓ Réveil 13/05/2026 à 22H16."},
      {id:"003",ref:"REF/MED/2026-0515-T",name:"Tadao",date:"15 / 05 / 2026",unit:"Admission · Soins chirurgicaux",status:"traite",category:"Chirurgie",tags:["Infection","Amputation","Désarticulation épaule"],summary:"Infection du moignon après désarticulation d'épaule. Débridement chirurgical et antibiothérapie.",body:"⚠ INFECTION POST-AMPUTATION — Foyer infectieux actif moignon épaule droite.\n\nINTERVENTIONS — Ablation sutures infectées, lavage sous pression, débridement, prélèvements bactério, pansement hydrofibres, Baie Oran, Comfey.\nTRAITEMENT — Antibiotiques IV (Amoxicilline-Ac. Clavulanique), anti-inflammatoires locaux."},
      {id:"004",ref:"REF/MED/2026-0515-AD",name:"Alex Delacroix",date:"15 / 05 / 2026",unit:"Consultation externe",status:"traite",category:"Toxicologie",tags:["Intoxication","Spores Raphlesia","Perte de connaissance"],summary:"Certificat attestant intoxication involontaire par spores de Raphlesia. Aucun traitement.",body:"Intoxication spores Raphlesia sans consentement. Perte de connaissance prolongée. Aucun traitement administré.\nPREUVES — Spores identifiées microscope, GABA élevé, mélatonine induite, résidus polliniques documentés.\n⚖ Preuve recevable Ligue Pokémon."},
      {id:"005",ref:"REF/MED/2026-0515-YY",name:"Yummi Yamo",date:"15 / 05 / 2026",unit:"Consultation externe",status:"traite",category:"Toxicologie",tags:["Intoxication","Spores Raphlesia","Perte de connaissance"],summary:"Certificat attestant intoxication involontaire par spores de Raphlesia. Aucun traitement.",body:"Intoxication spores Raphlesia sans consentement. Perte de connaissance prolongée. Aucun traitement administré.\nPREUVES — Spores identifiées microscope, GABA élevé, mélatonine induite, résidus polliniques documentés.\n⚖ Preuve recevable Ligue Pokémon."},
      {id:"006",ref:"REF/MED/2026-0515-TD",name:"Tony Delord",date:"15 / 05 / 2026",unit:"Admission · Urgences chirurgicales",status:"traite",category:"Médecine légale",tags:["Pendaison forcée","Traumatisme cervical","Médico-légal"],summary:"Pendaison forcée suivie d'une chute. Bilan neurologique rassurant, sortie autorisée.",body:"⚠ SIGNALEMENT MÉDICO-LÉGAL — Pendaison forcée, marques de lutte, signalement autorités.\nINTERVENTIONS — Intubation, scanner (RAS), écho-doppler (RAS), cartographie ecchymoses, prélèvements.\nTRAITEMENT — Corticoïdes IV, Mannitol, Morphine, Antibiotiques.\n✓ Réveil confirmé, sortie autorisée."},
      {id:"007",ref:"REF/MED/2026-0515-KU",name:"Kimaru Ukasai",date:"15 / 05 / 2026",unit:"Admission · Traumatologie",status:"traite",category:"Traumatologie",tags:["Fracture","Chute 3-4m"],summary:"Fractures légères col du fémur et calcanéum. Sortie avec béquille.",body:"Chute 3-4m sur membres inférieurs.\nDIAGNOSTICS — Fracture légère col fémur + calcanéum.\nTRAITEMENT — Antalgie, crème Baie Sitrus, béquille.\n✓ Sortie autorisée, suivi externe."},
      {id:"001-OP",ref:"REF/MED/2026-0623-ZC",name:"Zerath Cobalt",date:"23 / 06 / 2026",unit:"Chirurgie programmée · Bloc opératoire",status:"traite",category:"Chirurgie",tags:["Chirurgie oculaire","Prothèse main","Orbite"],summary:"Double intervention : orbite définitive + prothèse main (pouce, index, paume). Aucune complication.",body:"ORBITE — Retrait conformateur provisoire, implant orbitaire poreux définitif, suture 6-0, conformateur acrylique, Tobramycine.\nMAIN — Plaque palmaire titane, tendons ancrés, pouce + index prothétiques verrouillés, Histoacryl, Baie Sitrus.\n✓ Aucune complication. Suivi : œil de verre définitif en externe."},
      {id:"008",ref:"REF/MED/2026-0623-LP",name:"Léo Poulino",date:"23 / 06 / 2026",unit:"Admission · Urgences chirurgicales",status:"traite",category:"Traumatologie",tags:["Fractures costales","Fracture fémur","Chirurgie simultanée"],summary:"Trois côtes + fémur opérés simultanément. Plaques costales + clou centromédullaire. Aucune complication.",body:"CÔTES — 3 fractures, plaques titane + vis 2mm, étanchéité pleurale confirmée.\nFÉMUR — Clou centromédullaire titane verrouillé, attelle plâtrée.\nTRAITEMENT — Antibiotiques, Morphine, Anticoagulants, Anti-inflammatoires, Baie Sitrus.\n✓ Contrôle radio à 6 semaines."},
      {id:"ML-001",ref:"REF/MED/2026-0623-ML",name:"Balash Mové",date:"23 / 06 / 2026 · 18H36",unit:"Unité médico-légale · Autopsie",status:"deces",category:"Médecine légale",tags:["Décès","Traumatisme crânien","Autopsie"],summary:"Autopsie. Décès par traumatisme crânien occipital. Toxicologie négative. Dossier clôturé.",body:"Décès à 18H36 le 23/06/2026. Lieu non communiqué.\nEXTERNE — Plaie occipitale, enfoncement osseux.\nINTERNE — Fracture occipitale étoilée, hématome extradural massif, engagement cérébral fatal.\nTOXICO — Tout négatif (sang, urine, humeur vitrée, venins Pokémon).\n✓ Cause exclusivement traumatique. Rapport transmis aux autorités."}
    ];
    const seeded = SEED.map(r => ({ ...r, createdAt: new Date().toISOString() }));
    writeAll(seeded);
    res.json({ ok: true, seeded: true, count: seeded.length });
  } catch (e) {
    res.status(500).json({ ok: false, error: e.message });
  }
});

// Toutes les autres routes → index.html
app.get("*", (req, res) => {
  res.sendFile(path.join(__dirname, "public", "index.html"));
});

app.listen(PORT, () => {
  console.log(`✚ Archives Flankin en ligne sur le port ${PORT}`);
});
