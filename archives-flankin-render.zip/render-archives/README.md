# Archives Médicales — Centre Hospitalier Flankin
## Déploiement sur Render.com (gratuit, sans carte bancaire)

---

### Structure du projet
```
render-archives/
├── server.mjs          → serveur Express (API + frontend)
├── package.json        → dépendances
├── public/
│   └── index.html      → le site complet
└── README.md
```

---

### Déploiement en 5 étapes

**1. Crée un compte GitHub** (si tu n'en as pas)
→ https://github.com — gratuit

**2. Crée un nouveau dépôt GitHub**
→ New repository → nom : `archives-flankin` → Public → Create

**3. Upload les fichiers**
→ Clique "uploading an existing file"
→ Glisse TOUT le contenu du dossier `render-archives` (server.mjs, package.json, le dossier public/)
→ Commit changes

**4. Déploie sur Render**
→ Va sur https://render.com → Sign up (gratuit, pas de CB)
→ New → Web Service
→ Connect your GitHub account → sélectionne `archives-flankin`
→ Remplis les champs :
   - Name : `archives-flankin`
   - Runtime : `Node`
   - Build Command : `npm install`
   - Start Command : `node server.mjs`
   - Instance Type : `Free`
→ Clique **Create Web Service**
→ Attends 2-3 minutes → Render te donne une URL : `https://archives-flankin.onrender.com`

**5. Pré-charge les dossiers existants**
→ Ouvre cette URL une seule fois dans ton navigateur :
```
https://archives-flankin.onrender.com/api/seed
```
→ Tu dois voir : `{"ok":true,"seeded":true,"count":10}`
→ Retourne sur l'accueil : les dossiers sont là !

---

### ⚠️ Note sur le stockage gratuit Render

Le plan gratuit de Render **ne garantit pas la persistance des fichiers** entre redémarrages.
Pour que les dossiers ajoutés survivent aux redémarrages :
- Upgrade vers un plan payant avec **Persistent Disk** (7$/mois)
- OU utilise une base de données gratuite comme **Supabase** ou **MongoDB Atlas**

Pour un usage roleplay/occasionnel, le plan gratuit convient — les dossiers
survivent tant que le service tourne. En cas de redémarrage, rappelle `/api/seed`.

---

### Partage du lien
Une fois en ligne, tu partages simplement :
```
https://archives-flankin.onrender.com
```
Tout le monde peut voir les dossiers et en ajouter de nouveaux.
